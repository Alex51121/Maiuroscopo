# 🐱 MIAUROSCOPO WEB

## Estructura del proyecto
```
miauroscopo_web/
├── app.py                 ← Servidor Flask (backend)
├── requirements.txt       ← Dependencias
├── Procfile               ← Para despliegue en Railway/Render
├── iniciar_servidor.bat   ← Lanzador local (Windows)
└── templates/
    ├── base.html          ← Layout base
    ├── home.html          ← Página de inicio
    ├── registro.html      ← Formulario de registro
    ├── login.html         ← Inicio de sesión
    ├── horoscopo.html     ← Horóscopo del usuario
    ├── admin_login.html   ← Login del admin
    └── admin_panel.html   ← Panel de administración
```

---

## 🚀 Uso local (en tu PC)

1. Haz doble clic en `iniciar_servidor.bat`
2. Abre tu navegador en `http://localhost:5000`
3. ¡Listo!

---

## 🌐 Publicar en internet GRATIS

### Opción recomendada: Railway

1. Crea cuenta gratis en https://railway.app
2. Instala Git si no lo tienes: https://git-scm.com
3. En la carpeta del proyecto, abre una terminal y ejecuta:

```bash
git init
git add .
git commit -m "Miauroscopo web"
```

4. En Railway: **New Project → Deploy from GitHub repo**
5. Conecta tu repositorio
6. Railway detecta el `Procfile` y despliega automáticamente
7. Te da una URL pública tipo `https://miauroscopo.up.railway.app`

### Opción alternativa: Render

1. Crea cuenta en https://render.com
2. New → Web Service → conecta tu repo de GitHub
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Deploy → te da URL pública gratuita

---

## 👤 Credenciales admin
- Usuario: `admin`
- Contraseña: `miauadmin`

## 📱 WhatsApp
- Requiere WhatsApp Web abierto
- Solo funciona desde el servidor local (no desde hosting en la nube)

---

*🐾 Con amor felino — Miauroscopo*
