@echo off
title Miauroscopo Web - Iniciando servidor...
color 0D

echo.
echo  ============================================
echo   🐱  MIAUROSCOPO WEB - Servidor Flask  🐱
echo  ============================================
echo.

IF NOT EXIST "venv\Scripts\activate.bat" (
    echo  [*] Creando entorno virtual...
    python -m venv venv
    call venv\Scripts\activate.bat
    pip install -r requirements.txt --quiet
) ELSE (
    call venv\Scripts\activate.bat
)

echo  [OK] Iniciando servidor en http://localhost:5000
echo.
echo  Abre tu navegador en: http://localhost:5000
echo  Para detener el servidor presiona Ctrl+C
echo.

python app.py

pause
